//816029635

public interface PortableDevice
{
   
}
